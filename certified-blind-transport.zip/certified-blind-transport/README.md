# certified-blind-transport

Two firms match orders on encrypted books. The result comes with a zero-knowledge certificate that the matching was optimal.

This repository holds the Rust workspace and the design documents. **Status: draft. M1 and M3 are implemented and tested. The other milestones are specified but not built** (see `docs/plan/README.md`). Nothing here is production cryptography: the CKKS parameters planned for the browser demo (TOY-12) are deliberately insecure and are labelled as such everywhere.

## What is here

| Path | Contents | Status |
|---|---|---|
| `crates/bt-arith` | modular arithmetic (Shoup, Barrett), deterministic Miller–Rabin, NTT-friendly primes, negacyclic NTT with Harvey lazy butterflies, Galois automorphisms | **M3 done**: 13 tests |
| `crates/bt-market` | market model, closed-form 1-D optimal transport, uniform-price duality certificate, rounding and proved tolerances, Π-selection protocol (plaintext oracle) | **M1 done**: 10 property tests over 20k random books each |
| `docs/M1-market-math.md` | M1 specification with full proofs (Theorems 1–7) | draft v1 |
| `docs/M3-ntt-math.md` | M3 specification with full proofs (CRT, CT/GS derivation, Shoup/Barrett bounds, lazy invariants, automorphisms) | draft v1 |
| `docs/plan/` | the build plan: architecture, toolchain, CKKS, threshold protocol, engine, ZK certificate, workers, UI, testing | plan |
| `spikes/` | Python experiments behind the design decisions (`docs/plan/04`) | runnable |

Inside the docs, a reference like `docs/05` means `docs/plan/05-*.md`.

## Run it

```bash
cargo test --workspace --release          # 23 tests, < 1 s
cargo clippy --workspace --all-targets    # clean
cargo run -p bt-market --example preset   # the demo books: trades, Π = $100.075, gap profile, masks
cargo run -p bt-arith  --example toy12_chain   # the TOY-12 prime chain (log2 QP = 840) with roots ψ
```

Both crates are `std`-only with no dependencies, so they should build unchanged for `wasm32-unknown-unknown`. This has **not yet been verified**: the sandbox these drafts were written in cannot install the wasm target. Run `rustup target add wasm32-unknown-unknown && cargo build --target wasm32-unknown-unknown` as the first M0 check. Developed on rustc 1.95.

## Key results in M1 (see the doc for proofs)

- The masked monotone (quantile) coupling is exactly optimal (Theorem 1). A single clearing price Π, chosen from 2L candidates, always certifies it with gap exactly 0 (Theorem 5).
- The gap splits as G = G_T + G_A + G_B: a public part plus one part per firm. Each firm proves its own part in ZK (Theorem 4).
- Honest CKKS runs with decryption error below κ always certify with δ_T = 0 and δ_A = δ_B = w_max(2L−1)·2κ = 1800 (Theorem 7).
- Whatever the server does, acceptance implies W(T) ≥ W* − 3600 units, i.e. $0.09 per share-per-lot (Theorem 6).

## Before you present this as your work

These two milestones were drafted for you. Before you defend them, own them:
1. Re-derive Theorems 1, 5 and 7 (M1) and Theorems 3.1, 4.1 and 7.1 (M3) on paper without looking.
2. Break each test on purpose (flip a sign, change κ, shift an index) and predict which assertion fails.
3. Read §12 of M1 and §11 of M3 ("what to be ready to defend") and answer each question out loud.
4. Do not claim novelty ("first") until the literature sweep in `docs/plan/11` is done.

## Licence

Apache-2.0 OR MIT.
